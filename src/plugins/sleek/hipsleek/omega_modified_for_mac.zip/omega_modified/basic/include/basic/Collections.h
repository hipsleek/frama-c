#if !defined Already_Included_Collections
#define Already_Included_Collections

#include <stdio.h>
#include <basic/Collection.h>
#include <basic/Iterator.h>
#include <basic/List.h>
#include <basic/Bag.h>
#include <basic/Map.h>

#endif 

