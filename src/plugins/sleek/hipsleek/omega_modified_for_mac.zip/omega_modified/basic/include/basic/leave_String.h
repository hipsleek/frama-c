namespace omega {
#undef String
//#undef enter_String_h
//}
