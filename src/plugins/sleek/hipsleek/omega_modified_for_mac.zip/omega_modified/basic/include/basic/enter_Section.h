namespace omega {
#if ! defined Section
#define Section Omega_Section
#define Section_Iterator Omega_Section_Iterator
#endif
}
