namespace omega {
#if ! defined Map
#define MapElement Omega_MapElement
#define MapElementIterator Omega_MapElementIterator
#define Map Omega_Map
#endif
}
