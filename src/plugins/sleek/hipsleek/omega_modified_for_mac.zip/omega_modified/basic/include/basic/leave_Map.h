namespace omega {
#undef MapElement
#undef MapElementIterator
#undef Map
}
