namespace omega {
#undef Tuple
#undef Tuple_Iterator
}
