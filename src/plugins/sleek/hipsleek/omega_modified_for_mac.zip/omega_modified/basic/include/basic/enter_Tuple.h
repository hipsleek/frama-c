namespace omega {
#if ! defined Tuple
#define Tuple Omega_Tuple
#define Tuple_Iterator Omega_Tuple_Iterator
#endif
}
