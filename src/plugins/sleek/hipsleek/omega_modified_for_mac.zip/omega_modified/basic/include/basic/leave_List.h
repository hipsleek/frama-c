namespace omega {
#undef List
#undef List_Iterator
}
