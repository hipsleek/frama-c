namespace omega {
#if ! defined Collection
#define Collection Omega_Collection
#define Sequence Omega_Sequence
#endif
}
