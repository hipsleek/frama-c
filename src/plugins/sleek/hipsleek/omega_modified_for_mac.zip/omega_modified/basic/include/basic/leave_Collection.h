namespace omega {
#undef Collection
#undef Sequence
}
