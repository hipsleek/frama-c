
#if !defined Rel_Op


#define  Rel_Op Omega_AST_Rel_Op
#define  eq Omega_AST_eq
#define  lt Omega_AST_lt
#define  gt Omega_AST_gt
#define  geq Omega_AST_geq
#define  leq Omega_AST_leq
#define  neq Omega_AST_neq

#endif
