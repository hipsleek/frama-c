#if defined DONT_INCLUDE_TEMPLATE_CODE

/* DONT BOTHER COMPILING THIS FILE UNLESS WE ARE USING G++ >= 260
   AND  -fno-implicit-templates AND -DDONT_INCLUDE_TEMPLATE_CODE  */

#undef DONT_INCLUDE_TEMPLATE_CODE

#include <omega/PT-omega.c>

// If we needed other templates, we would put them here

#endif
