/* langmenu.h,v 1.1.1.2 1992/07/10 02:40:28 davew Exp */
#ifndef Already_Included_Lang_Menu
#define Already_Included_Lang_Menu

namespace omega {

/* menu for petit -> fortran translation */
void *build_do_translate( void );
extern int do_translate_epilog( int dummy );

}

#endif
