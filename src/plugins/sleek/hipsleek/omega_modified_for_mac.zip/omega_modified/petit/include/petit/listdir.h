/* listdir.h,v 1.1.1.2 1992/07/10 02:40:39 davew Exp */
#ifndef Already_Included_Listdir
#define Already_Included_Listdir

namespace omega {

/* list current directory */

extern void listdir( void );

}

#endif
