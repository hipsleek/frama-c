namespace omega {

typedef
enum classes {
CLunknown,
CLAUTO,
CLCOMMON, CLSTATIC, CLFORMAL,
CLIN, CLOUT, CLINOUT,
CLBUILTIN,
CLPRIVATE
} var_class;


#define DIMSFUN 200

}
