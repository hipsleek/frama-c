/* $Id: f2p.h,v 1.1 2010-12-10 07:42:10 locle Exp $ */
#ifndef Already_Included_F2t
#define Already_Included_F2t

namespace omega {

extern void convert_to_petit();

}

#endif
