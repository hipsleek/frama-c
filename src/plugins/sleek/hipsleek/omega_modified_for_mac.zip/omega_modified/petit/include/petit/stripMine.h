/* $Id: stripMine.h,v 1.1 2010-12-10 07:42:13 locle Exp $ */
#ifndef Already_Included_stripMine
#define Already_Included_stripMine

namespace omega {

int strip_mine(void);

}

#endif
