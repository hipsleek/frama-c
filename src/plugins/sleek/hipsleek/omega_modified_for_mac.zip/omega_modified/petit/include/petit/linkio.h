/* linkio.h,v 1.1.1.2 1992/07/10 02:40:37 davew Exp */
#ifndef Already_Included_LinkIO
#define Already_Included_LinkIO

namespace omega {

/* make I/O lists; no arguments */
extern void link_lists( void );

}

#endif
