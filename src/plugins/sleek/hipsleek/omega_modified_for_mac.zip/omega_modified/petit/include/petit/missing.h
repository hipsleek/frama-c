/* missing.h,v 1.1.1.2 1992/07/10 02:40:55 davew Exp */
#ifndef Already_Included_Missing
#define Already_Included_Missing


/* You may need to comment these out */


// extern "C" char	*getwd(char *);
// extern "C" int    fprintf(FILE *, const char *, ...);

// extern "C" void getrusage (int, struct rusage*);

// #if (! defined ultrix)
// extern "C" char *   memcpy(char *, const char *, int);
// extern "C" char *   memset(char *, int, int);
// #endif /* memset decl */

#endif
