/* language.c,v 1.1.1.2 1992/07/10 02:43:16 davew Exp */

#include <petit/language.h>

namespace omega {
languagetype language = petitlang;
}

