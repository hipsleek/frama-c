/* $Id: q_stubs.c,v 1.1 2010-12-10 07:42:20 locle Exp $ */

namespace omega {
int quantify_record_data ()			    	  { return 0; }
int quantify_start_recording_data ()			  { return 0; }
int quantify_stop_recording_data ()			  { return 0; }
int quantify_record_system_calls ()		 	  { return 0; }
int quantify_start_recording_system_calls ()		  { return 0; }
int quantify_stop_recording_system_calls ()		  { return 0; }
int quantify_record_register_window_traps ()	 	  { return 0; }
int quantify_start_recording_register_window_traps ()     { return 0; }
int quantify_stop_recording_register_window_traps ()	  { return 0; }
int quantify_clear_data ()				  { return 0; }
int quantify_save_data ()	 			  { return 0; }
int quantify_save_data_to_file ()			  { return 0; }
int quantify_add_annotation ()				  { return 0; }
int quantify_help() 					  { return 0; }
int quantify_print_recording_state()			  { return 0; }
}
