lex lexEx.l
cc lex.yy.c -o lexEx -ll
