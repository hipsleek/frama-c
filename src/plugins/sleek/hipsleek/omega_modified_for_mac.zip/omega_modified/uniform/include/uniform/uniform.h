/* $Id: uniform.h,v 1.1 2010-12-10 07:42:37 locle Exp $ */
#ifndef Already_Included_Uniform
#define Already_Included_Uniform

namespace omega {

extern void uniform(char *args);

}

#endif
