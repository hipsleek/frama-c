/* $Id: */
#ifndef Already_Included_Communication
#define Already_Included_Communication

#include <uniform/search.h>

namespace omega {

extern search_cost compute_edge_cost(int p, int q, int cp, int cq);

}

#endif
