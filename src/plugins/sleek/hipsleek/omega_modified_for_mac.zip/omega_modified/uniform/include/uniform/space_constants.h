/* $Id: */
#ifndef Already_Included_Space_Constants
#define Already_Included_Space_Constants

namespace omega {

extern Dynamic_Array2<int> best_coef;

extern void select_constants();

}

#endif
