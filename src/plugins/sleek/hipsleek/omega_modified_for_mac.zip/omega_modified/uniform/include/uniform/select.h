/* $Id: select.h,v 1.1 2010-12-10 07:42:37 locle Exp $ */
#ifndef Already_Included_Select
#define Already_Included_Select

namespace omega {

extern void traverse();

}

#endif
